/*jslint devel: true */
/*global define */
"use strict";

console.log("Inside login.js");