/*global Backbone, jQuery, console */
var app = app || {};

jQuery(function ($) {
    'use strict';

    app.TodoCL = {
        tagName: 'li',

        clInit: function () {
            console.log("Inside test2#clInit");
        },

        clDestroy: function () {
            console.log("Inside test2#clDestroy");
        }
    };
});