/*global Backbone, jQuery, console */
var app = app || {};

jQuery(function ($) {
    'use strict';

    app.TodoView = {
        tagName: 'li',

        initialize: function () {
            console.log("Inside test1#initialize");
        },

        clear: function () {
            console.log("Inside test1#clear");
        }
    };
    app.TodoView.clear();
    app.TodoCL.clDestroy();

});